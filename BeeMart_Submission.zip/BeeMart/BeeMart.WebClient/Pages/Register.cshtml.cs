using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BeeMart.WebClient.Pages;

public class RegisterModel : PageModel
{
    public void OnGet() { }
}
