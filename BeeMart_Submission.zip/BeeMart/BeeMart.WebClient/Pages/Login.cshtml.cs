using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BeeMart.WebClient.Pages;

public class LoginModel : PageModel
{
    public void OnGet() { }
}
