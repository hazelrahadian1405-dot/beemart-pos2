using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BeeMart.WebClient.Pages;

public class TransactionModel : PageModel
{
    public void OnGet() { }
}
