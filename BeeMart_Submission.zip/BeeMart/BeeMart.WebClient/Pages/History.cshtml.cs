using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BeeMart.WebClient.Pages;

public class HistoryModel : PageModel
{
    public void OnGet() { }
}
