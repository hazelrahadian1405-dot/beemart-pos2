using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BeeMart.WebClient.Pages;

public class IndexModel : PageModel
{
    public void OnGet() { }
}
