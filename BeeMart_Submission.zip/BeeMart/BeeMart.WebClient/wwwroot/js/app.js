/* BeeMart shared frontend helpers.
   All data access goes through the Backend API — the WebClient never touches the DB. */
(function () {
  const API = (window.BEEMART_CONFIG && window.BEEMART_CONFIG.apiBaseUrl) || "";
  const API_V1 = API.replace(/\/+$/, "") + "/api/v1";
  const TOKEN_KEY = "beemart_token";
  const USER_KEY = "beemart_user";
  const TZ = "Asia/Jakarta";

  // ---------- Session (who is logged in) ----------
  const Session = {
    save(login) {
      sessionStorage.setItem(TOKEN_KEY, login.token);
      sessionStorage.setItem(USER_KEY, JSON.stringify({
        idUser: login.idUser, username: login.username,
        fullName: login.fullName, role: login.role, expiresAt: login.expiresAt
      }));
    },
    token() { return sessionStorage.getItem(TOKEN_KEY); },
    user() {
      try { return JSON.parse(sessionStorage.getItem(USER_KEY)); }
      catch { return null; }
    },
    isAuthenticated() {
      const u = this.user();
      if (!this.token() || !u) return false;
      if (u.expiresAt && new Date(u.expiresAt) < new Date()) { this.clear(); return false; }
      return true;
    },
    clear() { sessionStorage.removeItem(TOKEN_KEY); sessionStorage.removeItem(USER_KEY); },
    /** Redirect to login if not authenticated. Returns the user when OK. */
    require() {
      if (!this.isAuthenticated()) { window.location.replace("/Login"); return null; }
      return this.user();
    }
  };

  // ---------- API fetch wrapper ----------
  class ApiError extends Error {
    constructor(message, status) { super(message); this.status = status; }
  }

  async function apiFetch(path, { method = "GET", body, auth = true } = {}) {
    const headers = { "Accept": "application/json" };
    if (body !== undefined) headers["Content-Type"] = "application/json";
    if (auth && Session.token()) headers["Authorization"] = "Bearer " + Session.token();

    let res;
    try {
      res = await fetch(API_V1 + path, {
        method, headers, body: body !== undefined ? JSON.stringify(body) : undefined
      });
    } catch {
      throw new ApiError("Tidak dapat terhubung ke server API. Pastikan BeeMart.Api sedang berjalan.", 0);
    }

    let payload = null;
    const text = await res.text();
    if (text) { try { payload = JSON.parse(text); } catch { /* non-JSON body */ } }

    // An expired/invalid token on a protected call -> back to login.
    if (res.status === 401 && auth) {
      Session.clear();
      window.location.replace("/Login");
      throw new ApiError("Sesi berakhir, silakan login kembali.", 401);
    }
    if (res.status === 403) throw new ApiError("Anda tidak memiliki akses untuk fitur ini.", 403);

    if (!res.ok || (payload && payload.success === false)) {
      const msg = (payload && payload.message) || `Permintaan gagal (HTTP ${res.status})`;
      throw new ApiError(msg, res.status);
    }
    return payload; // ApiResponse<T> envelope: { success, message, data }
  }

  // ---------- Toast popup ----------
  function toast(message, type = "info", ms = 3500) {
    let root = document.getElementById("toast-root");
    if (!root) { root = document.createElement("div"); root.id = "toast-root"; document.body.appendChild(root); }
    const el = document.createElement("div");
    el.className = "toast " + type;
    el.setAttribute("role", type === "error" ? "alert" : "status");
    el.textContent = message;
    root.appendChild(el);
    setTimeout(() => { el.style.opacity = "0"; setTimeout(() => el.remove(), 260); }, ms);
  }

  // ---------- Indonesian formatting ----------
  const rupiah = new Intl.NumberFormat("id-ID", {
    style: "currency", currency: "IDR", minimumFractionDigits: 0, maximumFractionDigits: 2
  });
  /** 35000 -> "Rp 35.000" */
  function formatIDR(v) { return rupiah.format(Number(v) || 0).replace(/\u00a0/g, " "); }

  /** 5 -> "5%", 2.5 -> "2,5%" */
  function formatPercent(v) { return (Number(v) || 0).toLocaleString("id-ID", { maximumFractionDigits: 2 }) + "%"; }

  /** Weight is stored in grams (database.sql): 85 -> "85 g", 1500 -> "1,5 Kg", 2000 -> "2 Kg" */
  function formatWeight(v) {
    const g = Number(v) || 0;
    const fmt = n => n.toLocaleString("id-ID", { maximumFractionDigits: 2 });
    return g >= 1000 ? fmt(g / 1000) + " Kg" : fmt(g) + " g";
  }

  /** API dates are WIB wall-clock values ("2026-09-04T10:35:12.123"). -> "2026-09-04 10:35" */
  function formatDateTime(iso) {
    if (!iso) return "";
    const m = /^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2})/.exec(iso);
    return m ? `${m[1]} ${m[2]}` : iso;
  }

  /** Live clock in WIB, e.g. "4/9/2026, 10.32.46" (as in the mockup). */
  function nowWibText() {
    return new Date().toLocaleString("id-ID", { timeZone: TZ });
  }

  function escapeHtml(s) {
    return String(s ?? "").replace(/[&<>"']/g, c =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }

  function roleLabel(role) { return role === "Cashier" ? "Kasir" : role; }

  /**
   * Fill the header bar.
   *  - "clock":   "<live WIB time> | Kasir: <username>"   (New Transaction mockup)
   *  - "session": "Role: <role> | Login: <username>"       (History spec + mockup)
   */
  function initHeader(user, mode) {
    const el = document.getElementById("sessionInfo");
    if (el) {
      if (mode === "clock") {
        const render = () => {
          el.innerHTML = `${escapeHtml(nowWibText())} | ${escapeHtml(roleLabel(user.role))}: ${escapeHtml(user.username)}`;
        };
        render();
        setInterval(render, 1000);
      } else {
        el.innerHTML = `Role: <span class="hl">${escapeHtml(user.role)}</span> | Login: ${escapeHtml(user.username)}`;
      }
    }
    const logout = document.getElementById("logoutBtn");
    if (logout) logout.addEventListener("click", () => { Session.clear(); window.location.replace("/Login"); });
  }

  window.BeeMart = {
    API_V1, Session, apiFetch, ApiError, toast,
    formatIDR, formatPercent, formatWeight, formatDateTime, escapeHtml, initHeader
  };
})();
