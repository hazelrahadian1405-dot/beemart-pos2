/* History Transaction page. The API decides what each role may see:
   Cashier -> own transactions only, Admin -> all cashiers. Max 20 rows/page, ascending. */
(function () {
    const user = BeeMart.Session.require();
    if (!user) return;
    BeeMart.initHeader(user, "session");   // "Role: <role> | Login: <username>"

    const { apiFetch, toast, formatIDR, formatDateTime, escapeHtml } = BeeMart;
    const PAGE_SIZE = 20;

    const dateFilter = document.getElementById("dateFilter");
    const historyBody = document.getElementById("historyBody");
    const pagination = document.getElementById("pagination");

    document.getElementById("scopeNote").textContent = user.role === "Admin"
        ? "(Menampilkan Semua Kasir)"
        : `(Hanya Kasir: ${user.username})`;

    let currentDate = null;

    document.getElementById("searchBtn").addEventListener("click", () => {
        if (!dateFilter.value) {
            toast("Silakan pilih tanggal transaksi terlebih dahulu.", "error");
            dateFilter.focus();
            return;
        }
        currentDate = dateFilter.value;   // yyyy-MM-dd from the date picker
        load(1);
    });

    async function load(page) {
        historyBody.innerHTML = `<tr><td colspan="6" class="empty">Memuat data...</td></tr>`;
        pagination.innerHTML = "";
        try {
            const resp = await apiFetch(
                `/transactions/history?date=${encodeURIComponent(currentDate)}&page=${page}&pageSize=${PAGE_SIZE}`);
            render(resp.data);
        } catch (err) {
            historyBody.innerHTML = `<tr><td colspan="6" class="empty">${escapeHtml(err.message)}</td></tr>`;
            toast(err.message, "error");
        }
    }

    function render(result) {
        const items = result.items || [];
        if (!items.length) {
            historyBody.innerHTML = `<tr><td colspan="6" class="empty">Tidak ada transaksi pada tanggal ini.</td></tr>`;
            return;
        }
        historyBody.innerHTML = items.map(t => `
            <tr>
                <td>${escapeHtml(t.invoiceNo)}</td>
                <td>${escapeHtml(formatDateTime(t.transactionDate))}</td>
                <td>${escapeHtml(t.cashierName)}</td>
                <td>${t.itemCount}</td>
                <td>${escapeHtml(t.paymentMethod)}</td>
                <td>${formatIDR(t.totalPrice)}</td>
            </tr>`).join("");

        let html = "";
        for (let p = 1; p <= result.totalPages; p++) {
            html += `<button type="button" data-page="${p}" class="${p === result.page ? "active" : ""}">${p}</button>`;
        }
        pagination.innerHTML = html;
    }

    pagination.addEventListener("click", e => {
        const btn = e.target.closest("button[data-page]");
        if (btn && !btn.classList.contains("active")) load(Number(btn.dataset.page));
    });
})();
