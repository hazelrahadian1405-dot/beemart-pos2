var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorPages();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseRouting();
app.MapRazorPages();

// Expose the API base URL to the browser as a tiny JS config file.
var apiBaseUrl = app.Configuration["ApiBaseUrl"] ?? "https://localhost:7100";
app.MapGet("/config.js", () => Results.Content(
    $"window.BEEMART_CONFIG = {{ apiBaseUrl: '{apiBaseUrl}' }};",
    "application/javascript"));

app.Run();
