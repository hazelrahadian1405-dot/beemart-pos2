namespace BeeMart.Api.Models.Entities;

/// <summary>Master product catalog.</summary>
public class MsProduct
{
    public string IdProduct { get; set; } = default!;   // NVARCHAR(36) PK (GUID)
    public string Name { get; set; } = default!;        // NVARCHAR(100)
    public decimal Weight { get; set; }                 // DECIMAL(10,2)
    public int Stock { get; set; }                      // INT
    public decimal Price { get; set; }                  // DECIMAL(18,2)
    public decimal Discount { get; set; }               // DECIMAL(5,2) : percentage 0..100

    public bool Stsrc { get; set; } = true;
    public DateTime Datein { get; set; }
    public string Userin { get; set; } = default!;
    public DateTime? Dateup { get; set; }
    public string? Userup { get; set; }

    public ICollection<TrTransactionDetail> TransactionDetails { get; set; } = new List<TrTransactionDetail>();
}
