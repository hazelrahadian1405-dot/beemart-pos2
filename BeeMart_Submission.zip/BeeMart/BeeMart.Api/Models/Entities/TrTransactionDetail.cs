namespace BeeMart.Api.Models.Entities;

/// <summary>Transaction line item.</summary>
public class TrTransactionDetail
{
    public string IdTransactionDetail { get; set; } = default!; // NVARCHAR(36) PK (GUID)
    public string IdTransaction { get; set; } = default!;       // FK -> TrTransaction
    public string IdProduct { get; set; } = default!;           // FK -> MsProduct
    public int Qty { get; set; }                                // INT
    public decimal Price { get; set; }                          // DECIMAL(18,2) unit price at sale time
    public decimal Discount { get; set; }                       // DECIMAL(5,2) percentage at sale time
    public decimal SubTotal { get; set; }                       // DECIMAL(18,2)

    public bool Stsrc { get; set; } = true;
    public DateTime Datein { get; set; }
    public string Userin { get; set; } = default!;
    public DateTime? Dateup { get; set; }
    public string? Userup { get; set; }

    public TrTransaction? Transaction { get; set; }
    public MsProduct? Product { get; set; }
}
