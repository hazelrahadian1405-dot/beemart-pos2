namespace BeeMart.Api.Models.Entities;

/// <summary>Transaction header.</summary>
public class TrTransaction
{
    public string IdTransaction { get; set; } = default!;  // NVARCHAR(36) PK (GUID)
    public string InvoiceNo { get; set; } = default!;      // NVARCHAR(20) : [5 userId][ddmmyy][3 running]
    public DateTime TransactionDate { get; set; }          // DATETIME2
    public string IdUser { get; set; } = default!;         // FK -> MsUser
    public int IdPaymentMethod { get; set; }               // FK -> LtPaymentMethod
    public decimal TotalPrice { get; set; }                // DECIMAL(18,2)

    public bool Stsrc { get; set; } = true;
    public DateTime Datein { get; set; }
    public string Userin { get; set; } = default!;
    public DateTime? Dateup { get; set; }
    public string? Userup { get; set; }

    public MsUser? User { get; set; }
    public LtPaymentMethod? PaymentMethod { get; set; }
    public ICollection<TrTransactionDetail> Details { get; set; } = new List<TrTransactionDetail>();
}
