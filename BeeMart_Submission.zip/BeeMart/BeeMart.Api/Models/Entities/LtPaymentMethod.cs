namespace BeeMart.Api.Models.Entities;

/// <summary>Lookup table of payment methods (Cash / Debit / Credit).</summary>
public class LtPaymentMethod
{
    public int IdPaymentMethod { get; set; }            // INT PK (identity)
    public string MethodName { get; set; } = default!;  // NVARCHAR(50)

    public bool Stsrc { get; set; } = true;
    public DateTime Datein { get; set; }
    public string Userin { get; set; } = default!;
    public DateTime? Dateup { get; set; }
    public string? Userup { get; set; }

    public ICollection<TrTransaction> Transactions { get; set; } = new List<TrTransaction>();
}
