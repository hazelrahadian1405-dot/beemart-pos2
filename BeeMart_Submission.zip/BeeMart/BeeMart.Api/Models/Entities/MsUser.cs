namespace BeeMart.Api.Models.Entities;

/// <summary>
/// Master user table. Holds credentials and role (Admin / Cashier).
/// PK IdUser is a 5-character string used as the prefix of generated invoice numbers.
/// </summary>
public class MsUser
{
    public string IdUser { get; set; } = default!;        // NVARCHAR(5)  PK
    public string Username { get; set; } = default!;      // NVARCHAR(50)
    public string FullName { get; set; } = default!;      // NVARCHAR(300)
    public string PasswordHash { get; set; } = default!;  // NVARCHAR(255)
    public string Role { get; set; } = default!;          // NVARCHAR(20) : "Admin" | "Cashier"

    // Audit columns
    public bool Stsrc { get; set; } = true;               // soft-delete / active flag
    public DateTime Datein { get; set; }
    public string Userin { get; set; } = default!;
    public DateTime? Dateup { get; set; }
    public string? Userup { get; set; }

    public ICollection<TrTransaction> Transactions { get; set; } = new List<TrTransaction>();
}
