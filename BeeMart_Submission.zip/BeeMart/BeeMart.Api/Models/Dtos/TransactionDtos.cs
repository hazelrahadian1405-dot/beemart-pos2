using System.ComponentModel.DataAnnotations;

namespace BeeMart.Api.Models.Dtos;

public class CreateTransactionItem
{
    [Required(ErrorMessage = "Barang wajib dipilih")]
    public string IdProduct { get; set; } = default!;

    [Range(1, int.MaxValue, ErrorMessage = "Qty minimal 1")]
    public int Qty { get; set; }
}

public class CreateTransactionRequest
{
    [Range(1, int.MaxValue, ErrorMessage = "Metode pembayaran wajib dipilih")]
    public int IdPaymentMethod { get; set; }

    [MinLength(1, ErrorMessage = "Keranjang belanja masih kosong")]
    public List<CreateTransactionItem> Items { get; set; } = new();
}

public class NextInvoiceDto
{
    public string InvoiceNo { get; set; } = default!;
}

public class TransactionDetailDto
{
    public string IdProduct { get; set; } = default!;
    public string ProductName { get; set; } = default!;
    public int Qty { get; set; }
    public decimal Price { get; set; }
    public decimal Discount { get; set; }
    public decimal SubTotal { get; set; }
}

public class TransactionDto
{
    public string IdTransaction { get; set; } = default!;
    public string InvoiceNo { get; set; } = default!;
    public DateTime TransactionDate { get; set; }
    public string IdUser { get; set; } = default!;
    public string CashierName { get; set; } = default!;
    public string Username { get; set; } = default!;
    public int IdPaymentMethod { get; set; }
    public string PaymentMethod { get; set; } = default!;
    /// <summary>Total quantity of items in the transaction ("Jml Item").</summary>
    public int ItemCount { get; set; }
    public decimal TotalPrice { get; set; }
    public List<TransactionDetailDto> Details { get; set; } = new();
}
