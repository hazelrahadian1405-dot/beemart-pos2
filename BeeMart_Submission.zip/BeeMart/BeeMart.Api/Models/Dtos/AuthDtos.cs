using System.ComponentModel.DataAnnotations;

namespace BeeMart.Api.Models.Dtos;

public class LoginRequest
{
    [Required(ErrorMessage = "Username wajib diisi")]
    public string Username { get; set; } = default!;

    [Required(ErrorMessage = "Password wajib diisi")]
    public string Password { get; set; } = default!;

    [Required(ErrorMessage = "Role wajib dipilih")]
    public string Role { get; set; } = default!;   // "Admin" | "Cashier"
}

public class LoginResponse
{
    public string Token { get; set; } = default!;
    public string IdUser { get; set; } = default!;
    public string Username { get; set; } = default!;
    public string FullName { get; set; } = default!;
    public string Role { get; set; } = default!;
    public DateTime ExpiresAt { get; set; }
}

public class RegisterRequest
{
    [Required(ErrorMessage = "Username wajib diisi")]
    [StringLength(50, ErrorMessage = "Username maksimal 50 karakter")]
    public string Username { get; set; } = default!;

    [Required(ErrorMessage = "Full Name wajib diisi")]
    [StringLength(300, ErrorMessage = "Full Name maksimal 300 karakter")]
    public string FullName { get; set; } = default!;

    [Required(ErrorMessage = "Password wajib diisi")]
    public string Password { get; set; } = default!;

    [Required(ErrorMessage = "Re-Password wajib diisi")]
    [Compare(nameof(Password), ErrorMessage = "Password dan Re-Password tidak sama")]
    public string RePassword { get; set; } = default!;

    /// <summary>"Admin" or "Cashier" (the mockup's Role dropdown). Defaults to Cashier.</summary>
    public string? Role { get; set; }
}
