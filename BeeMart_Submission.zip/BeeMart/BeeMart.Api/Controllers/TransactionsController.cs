using System.Security.Claims;
using Asp.Versioning;
using BeeMart.Api.Models.Dtos;
using BeeMart.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BeeMart.Api.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/v{version:apiVersion}/[controller]")]
[Authorize(Roles = "Admin,Cashier")]
public class TransactionsController : ControllerBase
{
    private readonly ITransactionService _transactions;
    public TransactionsController(ITransactionService transactions) => _transactions = transactions;

    /// <summary>Preview of the invoice number for the current user's next transaction.</summary>
    [HttpGet("next-invoice")]
    public async Task<IActionResult> NextInvoice(CancellationToken ct)
    {
        try
        {
            var no = await _transactions.PeekNextInvoiceAsync(CurrentUserId, ct);
            return Ok(ApiResponse<NextInvoiceDto>.Ok(new NextInvoiceDto { InvoiceNo = no }));
        }
        catch (ServiceException ex)
        {
            return BadRequest(ApiResponse<object>.Fail(ex.Message));
        }
    }

    /// <summary>Create a new transaction (Admin & Cashier). Invoice number is generated server-side.</summary>
    [HttpPost]
    public async Task<IActionResult> Create([FromBody] CreateTransactionRequest req, CancellationToken ct)
    {
        try
        {
            var dto = await _transactions.CreateAsync(CurrentUserId, CurrentUsername, req, ct);
            return Ok(ApiResponse<TransactionDto>.Ok(dto, "Transaksi berhasil disimpan"));
        }
        catch (ServiceException ex)
        {
            return BadRequest(ApiResponse<object>.Fail(ex.Message));
        }
    }

    /// <summary>
    /// Paged transaction history for a given date (required).
    /// Cashier sees only their own; Admin sees all. Max 20 per page, ordered by date ascending.
    /// </summary>
    [HttpGet("history")]
    public async Task<IActionResult> History(
        [FromQuery] DateOnly? date,
        [FromQuery] int page = 1,
        [FromQuery] int pageSize = 20,
        CancellationToken ct = default)
    {
        if (date is null)
            return BadRequest(ApiResponse<object>.Fail("Tanggal transaksi wajib dipilih"));

        var result = await _transactions.GetHistoryAsync(CurrentUserId, CurrentRole, date.Value, page, pageSize, ct);
        return Ok(ApiResponse<PagedResult<TransactionDto>>.Ok(result));
    }

    private string CurrentUserId => User.FindFirstValue("idUser") ?? "";
    private string CurrentUsername => User.FindFirstValue(ClaimTypes.Name) ?? "";
    private string CurrentRole => User.FindFirstValue(ClaimTypes.Role) ?? "";
}
