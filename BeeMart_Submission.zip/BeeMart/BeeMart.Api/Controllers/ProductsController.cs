using Asp.Versioning;
using BeeMart.Api.Models.Dtos;
using BeeMart.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BeeMart.Api.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/v{version:apiVersion}/[controller]")]
[Authorize(Roles = "Admin,Cashier")]
public class ProductsController : ControllerBase
{
    private readonly IProductService _products;
    public ProductsController(IProductService products) => _products = products;

    /// <summary>Search products by name (max 10 results).</summary>
    [HttpGet("search")]
    public async Task<IActionResult> Search([FromQuery] string? keyword, CancellationToken ct)
    {
        var result = await _products.SearchAsync(keyword, ct);
        return Ok(ApiResponse<IReadOnlyList<ProductDto>>.Ok(result));
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> Get(string id, CancellationToken ct)
    {
        var product = await _products.GetAsync(id, ct);
        return product is null
            ? NotFound(ApiResponse<object>.Fail("Product not found"))
            : Ok(ApiResponse<ProductDto>.Ok(product));
    }
}
