using Asp.Versioning;
using BeeMart.Api.Models.Dtos;
using BeeMart.Api.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace BeeMart.Api.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/v{version:apiVersion}/[controller]")]
[Authorize(Roles = "Admin,Cashier")]
public class PaymentMethodsController : ControllerBase
{
    private readonly IProductService _products;
    public PaymentMethodsController(IProductService products) => _products = products;

    /// <summary>Payment methods (Cash/Debit/Credit) fetched dynamically by the WebClient.</summary>
    [HttpGet]
    public async Task<IActionResult> Get(CancellationToken ct)
    {
        var methods = await _products.GetPaymentMethodsAsync(ct);
        return Ok(ApiResponse<IReadOnlyList<PaymentMethodDto>>.Ok(methods));
    }
}
