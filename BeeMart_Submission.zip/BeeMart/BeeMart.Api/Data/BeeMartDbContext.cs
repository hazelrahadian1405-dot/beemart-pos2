using BeeMart.Api.Models.Entities;
using Microsoft.EntityFrameworkCore;

namespace BeeMart.Api.Data;

public class BeeMartDbContext : DbContext
{
    public BeeMartDbContext(DbContextOptions<BeeMartDbContext> options) : base(options) { }

    public DbSet<MsUser> MsUsers => Set<MsUser>();
    public DbSet<MsProduct> MsProducts => Set<MsProduct>();
    public DbSet<LtPaymentMethod> LtPaymentMethods => Set<LtPaymentMethod>();
    public DbSet<TrTransaction> TrTransactions => Set<TrTransaction>();
    public DbSet<TrTransactionDetail> TrTransactionDetails => Set<TrTransactionDetail>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        b.Entity<MsUser>(e =>
        {
            e.ToTable("MsUser");
            e.HasKey(x => x.IdUser);
            e.Property(x => x.IdUser).HasColumnType("nvarchar(5)");
            e.Property(x => x.Username).HasColumnType("nvarchar(50)").IsRequired();
            e.Property(x => x.FullName).HasColumnType("nvarchar(300)").IsRequired();
            e.Property(x => x.PasswordHash).HasColumnType("nvarchar(255)").IsRequired();
            e.Property(x => x.Role).HasColumnType("nvarchar(20)").IsRequired();
            e.Property(x => x.Datein).HasColumnType("datetime2");
            e.Property(x => x.Dateup).HasColumnType("datetime2");
            e.Property(x => x.Userin).HasColumnType("nvarchar(36)").IsRequired();
            e.Property(x => x.Userup).HasColumnType("nvarchar(36)");
            e.HasIndex(x => x.Username).IsUnique();
        });

        b.Entity<MsProduct>(e =>
        {
            e.ToTable("MsProduct");
            e.HasKey(x => x.IdProduct);
            e.Property(x => x.IdProduct).HasColumnType("nvarchar(36)");
            e.Property(x => x.Name).HasColumnType("nvarchar(100)").IsRequired();
            e.Property(x => x.Weight).HasColumnType("decimal(10,2)");
            e.Property(x => x.Price).HasColumnType("decimal(18,2)");
            e.Property(x => x.Discount).HasColumnType("decimal(5,2)");
            e.Property(x => x.Datein).HasColumnType("datetime2");
            e.Property(x => x.Dateup).HasColumnType("datetime2");
            e.Property(x => x.Userin).HasColumnType("nvarchar(36)").IsRequired();
            e.Property(x => x.Userup).HasColumnType("nvarchar(36)");
            e.HasIndex(x => x.Name);
        });

        b.Entity<LtPaymentMethod>(e =>
        {
            e.ToTable("LtPaymentMethod");
            e.HasKey(x => x.IdPaymentMethod);
            e.Property(x => x.IdPaymentMethod).ValueGeneratedOnAdd();
            e.Property(x => x.MethodName).HasColumnType("nvarchar(50)").IsRequired();
            e.Property(x => x.Datein).HasColumnType("datetime2");
            e.Property(x => x.Dateup).HasColumnType("datetime2");
            e.Property(x => x.Userin).HasColumnType("nvarchar(36)").IsRequired();
            e.Property(x => x.Userup).HasColumnType("nvarchar(36)");
        });

        b.Entity<TrTransaction>(e =>
        {
            e.ToTable("TrTransaction");
            e.HasKey(x => x.IdTransaction);
            e.Property(x => x.IdTransaction).HasColumnType("nvarchar(36)");
            e.Property(x => x.InvoiceNo).HasColumnType("nvarchar(20)").IsRequired();
            e.Property(x => x.TransactionDate).HasColumnType("datetime2");
            e.Property(x => x.IdUser).HasColumnType("nvarchar(5)").IsRequired();
            e.Property(x => x.TotalPrice).HasColumnType("decimal(18,2)");
            e.Property(x => x.Datein).HasColumnType("datetime2");
            e.Property(x => x.Dateup).HasColumnType("datetime2");
            e.Property(x => x.Userin).HasColumnType("nvarchar(36)").IsRequired();
            e.Property(x => x.Userup).HasColumnType("nvarchar(36)");
            e.HasIndex(x => x.InvoiceNo).IsUnique();
            e.HasIndex(x => x.TransactionDate);

            e.HasOne(x => x.User)
                .WithMany(u => u.Transactions)
                .HasForeignKey(x => x.IdUser)
                .OnDelete(DeleteBehavior.Restrict);

            e.HasOne(x => x.PaymentMethod)
                .WithMany(p => p.Transactions)
                .HasForeignKey(x => x.IdPaymentMethod)
                .OnDelete(DeleteBehavior.Restrict);
        });

        b.Entity<TrTransactionDetail>(e =>
        {
            e.ToTable("TrTransactionDetail");
            e.HasKey(x => x.IdTransactionDetail);
            e.Property(x => x.IdTransactionDetail).HasColumnType("nvarchar(36)");
            e.Property(x => x.IdTransaction).HasColumnType("nvarchar(36)").IsRequired();
            e.Property(x => x.IdProduct).HasColumnType("nvarchar(36)").IsRequired();
            e.Property(x => x.Price).HasColumnType("decimal(18,2)");
            e.Property(x => x.Discount).HasColumnType("decimal(5,2)");
            e.Property(x => x.SubTotal).HasColumnType("decimal(18,2)");
            e.Property(x => x.Datein).HasColumnType("datetime2");
            e.Property(x => x.Dateup).HasColumnType("datetime2");
            e.Property(x => x.Userin).HasColumnType("nvarchar(36)").IsRequired();
            e.Property(x => x.Userup).HasColumnType("nvarchar(36)");

            e.HasOne(x => x.Transaction)
                .WithMany(t => t.Details)
                .HasForeignKey(x => x.IdTransaction)
                .OnDelete(DeleteBehavior.Cascade);

            e.HasOne(x => x.Product)
                .WithMany(p => p.TransactionDetails)
                .HasForeignKey(x => x.IdProduct)
                .OnDelete(DeleteBehavior.Restrict);
        });
    }
}
