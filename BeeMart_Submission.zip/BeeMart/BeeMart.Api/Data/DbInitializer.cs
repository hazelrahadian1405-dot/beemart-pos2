using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage;

namespace BeeMart.Api.Data;

/// <summary>
/// First-run database setup. <c>database.sql</c> is the single source of truth for the
/// schema and seed data (payment methods, 370 products, admin + kasir accounts).
///  - Database missing      -> create it, then run database.sql.
///  - Database has no tables -> run database.sql.
///  - Tables already exist  -> do nothing.
/// </summary>
public static class DbInitializer
{
    public static async Task InitializeAsync(IServiceProvider services, IConfiguration config, ILogger logger)
    {
        if (!config.GetValue("SeedOnStartup", true))
            return;

        using var scope = services.CreateScope();
        var db = scope.ServiceProvider.GetRequiredService<BeeMartDbContext>();

        // Only relational providers can run the script (tests may use InMemory).
        if (!db.Database.IsRelational())
            return;

        try
        {
            // Time-box startup so the app still boots quickly when SQL Server is down.
            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(15));
            var creator = db.GetService<IRelationalDatabaseCreator>();

            if (!await creator.ExistsAsync(cts.Token))
            {
                await creator.CreateAsync(cts.Token);
                logger.LogInformation("Created empty BeeMart database.");
            }
            else if (await creator.HasTablesAsync(cts.Token))
            {
                return; // already set up
            }

            var scriptPath = Path.Combine(AppContext.BaseDirectory, "database.sql");
            if (!File.Exists(scriptPath))
            {
                logger.LogWarning("database.sql not found at {Path}; run it manually.", scriptPath);
                return;
            }

            var script = await File.ReadAllTextAsync(scriptPath, cts.Token);

            // Plain ADO.NET command: the script text is sent verbatim. (ExecuteSqlRaw would run it
            // through string.Format and fail on any '{' or '}' in the file, e.g. inside comments.)
            var conn = db.Database.GetDbConnection();
            await conn.OpenAsync(cts.Token);
            try
            {
                await using var cmd = conn.CreateCommand();
                cmd.CommandText = script;
                cmd.CommandTimeout = 120;
                await cmd.ExecuteNonQueryAsync(cts.Token);
            }
            finally
            {
                await conn.CloseAsync();
            }
            logger.LogInformation("Ran database.sql: BeeMart schema and seed data created.");
        }
        catch (Exception ex)
        {
            logger.LogWarning(ex, "Database setup skipped (SQL Server not reachable or script failed). " +
                                  "Run database.sql manually against the BeeMart database.");
        }
    }
}
