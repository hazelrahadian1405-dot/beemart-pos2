using BeeMart.Api.Data;
using BeeMart.Api.Models.Dtos;
using BeeMart.Api.Models.Entities;
using Microsoft.EntityFrameworkCore;

namespace BeeMart.Api.Services;

public class ServiceException : Exception
{
    public ServiceException(string message) : base(message) { }
}

public interface IAuthService
{
    Task<LoginResponse> LoginAsync(LoginRequest req, CancellationToken ct = default);
    Task RegisterAsync(RegisterRequest req, CancellationToken ct = default);
}

public class AuthService : IAuthService
{
    private readonly BeeMartDbContext _db;
    private readonly IPasswordHasher _hasher;
    private readonly IJwtTokenService _jwt;
    private readonly IDateTimeProvider _clock;

    private static readonly string[] ValidRoles = { "Admin", "Cashier" };

    public AuthService(BeeMartDbContext db, IPasswordHasher hasher, IJwtTokenService jwt, IDateTimeProvider clock)
    {
        _db = db;
        _hasher = hasher;
        _jwt = jwt;
        _clock = clock;
    }

    public async Task<LoginResponse> LoginAsync(LoginRequest req, CancellationToken ct = default)
    {
        var user = await _db.MsUsers
            .FirstOrDefaultAsync(u => u.Username == req.Username && u.Role == req.Role && u.Stsrc, ct);

        // Verify even on miss is not needed; but keep the message generic per spec: "Invalid login".
        if (user is null || !_hasher.Verify(req.Password, user.PasswordHash))
            throw new ServiceException("Invalid login");

        var (token, expires) = _jwt.Create(user);
        return new LoginResponse
        {
            Token = token,
            IdUser = user.IdUser,
            Username = user.Username,
            FullName = user.FullName,
            Role = user.Role,
            ExpiresAt = expires
        };
    }

    public async Task RegisterAsync(RegisterRequest req, CancellationToken ct = default)
    {
        bool exists = await _db.MsUsers.AnyAsync(u => u.Username == req.Username, ct);
        if (exists)
            throw new ServiceException("username has already exists");

        var role = string.IsNullOrWhiteSpace(req.Role) ? "Cashier" : req.Role!;
        if (!ValidRoles.Contains(role))
            throw new ServiceException("Invalid role");

        var now = _clock.NowWib;
        var user = new MsUser
        {
            IdUser = await NextUserIdAsync(ct),
            Username = req.Username,
            FullName = req.FullName,
            PasswordHash = _hasher.Hash(req.Password),
            Role = role,
            Stsrc = true,
            Datein = now,
            Userin = req.Username
        };

        _db.MsUsers.Add(user);
        await _db.SaveChangesAsync(ct);
    }

    /// <summary>Generates the next 5-digit zero-padded user id (e.g. 00001, 00002...).</summary>
    private async Task<string> NextUserIdAsync(CancellationToken ct)
    {
        var ids = await _db.MsUsers
            .Select(u => u.IdUser)
            .ToListAsync(ct);

        int max = 0;
        foreach (var id in ids)
            if (int.TryParse(id, out var n) && n > max) max = n;

        return (max + 1).ToString("D5");
    }
}
