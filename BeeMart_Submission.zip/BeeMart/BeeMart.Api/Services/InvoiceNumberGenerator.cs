using System.Globalization;
using BeeMart.Api.Data;
using Microsoft.EntityFrameworkCore;

namespace BeeMart.Api.Services;

public interface IInvoiceNumberGenerator
{
    /// <summary>
    /// Builds an invoice number: [5-digit userId][ddmmyy][3-digit running number].
    /// The running number is shared by all cashiers and restarts every day
    /// (matches the mockup: 66859030926001, 55794030926002, 78886030926003, ...).
    /// </summary>
    Task<string> NextAsync(string idUser, DateTime whenWib, CancellationToken ct = default);
}

public class InvoiceNumberGenerator : IInvoiceNumberGenerator
{
    private const int MaxRunningPerDay = 999;
    private readonly BeeMartDbContext _db;

    public InvoiceNumberGenerator(BeeMartDbContext db) => _db = db;

    public async Task<string> NextAsync(string idUser, DateTime whenWib, CancellationToken ct = default)
    {
        string userPart = (idUser ?? string.Empty).PadLeft(5, '0');
        if (userPart.Length > 5) userPart = userPart[^5..];

        string datePart = whenWib.ToString("ddMMyy", CultureInfo.InvariantCulture);

        var dayStart = whenWib.Date;
        var dayEnd = dayStart.AddDays(1);

        // Use the highest running number issued today (not a row count), so soft-deleted
        // or out-of-order rows can never cause a number to be reused.
        var todaysInvoices = await _db.TrTransactions
            .Where(t => t.TransactionDate >= dayStart && t.TransactionDate < dayEnd)
            .Select(t => t.InvoiceNo)
            .ToListAsync(ct);

        int max = 0;
        foreach (var inv in todaysInvoices)
        {
            if (inv.Length >= 3 && int.TryParse(inv[^3..], NumberStyles.None, CultureInfo.InvariantCulture, out var n) && n > max)
                max = n;
        }

        int next = max + 1;
        if (next > MaxRunningPerDay)
            throw new ServiceException("Batas nomor invoice harian (999) telah tercapai.");

        return userPart + datePart + next.ToString("D3", CultureInfo.InvariantCulture);
    }
}
