namespace BeeMart.Api.Services;

public interface IDateTimeProvider
{
    /// <summary>Current time in Indonesia Western Time (WIB, UTC+7).</summary>
    DateTime NowWib { get; }
}

public class DateTimeProvider : IDateTimeProvider
{
    private static readonly TimeZoneInfo Wib = ResolveWib();

    public DateTime NowWib => TimeZoneInfo.ConvertTimeFromUtc(DateTime.UtcNow, Wib);

    private static TimeZoneInfo ResolveWib()
    {
        foreach (var id in new[] { "Asia/Jakarta", "SE Asia Standard Time" })
        {
            try { return TimeZoneInfo.FindSystemTimeZoneById(id); }
            catch (TimeZoneNotFoundException) { }
            catch (InvalidTimeZoneException) { }
        }
        // Fallback: fixed +7 offset.
        return TimeZoneInfo.CreateCustomTimeZone("WIB", TimeSpan.FromHours(7), "WIB", "WIB");
    }
}
