using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using BeeMart.Api.Models.Entities;
using Microsoft.IdentityModel.Tokens;

namespace BeeMart.Api.Services;

public class JwtSettings
{
    public string Issuer { get; set; } = "BeeMart";
    public string Audience { get; set; } = "BeeMartClient";
    public string Key { get; set; } = default!;
    public int ExpiryMinutes { get; set; } = 480;
}

public interface IJwtTokenService
{
    (string token, DateTime expiresAt) Create(MsUser user);
}

public class JwtTokenService : IJwtTokenService
{
    private readonly JwtSettings _settings;
    private readonly IDateTimeProvider _clock;

    public JwtTokenService(JwtSettings settings, IDateTimeProvider clock)
    {
        _settings = settings;
        _clock = clock;
    }

    public (string token, DateTime expiresAt) Create(MsUser user)
    {
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_settings.Key));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.IdUser),
            new Claim("idUser", user.IdUser),
            new Claim(ClaimTypes.Name, user.Username),
            new Claim("fullName", user.FullName),
            new Claim(ClaimTypes.Role, user.Role),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
        };

        var expires = DateTime.UtcNow.AddMinutes(_settings.ExpiryMinutes);
        var token = new JwtSecurityToken(
            issuer: _settings.Issuer,
            audience: _settings.Audience,
            claims: claims,
            expires: expires,
            signingCredentials: creds);

        return (new JwtSecurityTokenHandler().WriteToken(token), expires);
    }
}
