using BeeMart.Api.Data;
using BeeMart.Api.Models.Dtos;
using Microsoft.EntityFrameworkCore;

namespace BeeMart.Api.Services;

public interface IProductService
{
    Task<IReadOnlyList<ProductDto>> SearchAsync(string? keyword, CancellationToken ct = default);
    Task<ProductDto?> GetAsync(string idProduct, CancellationToken ct = default);
    Task<IReadOnlyList<PaymentMethodDto>> GetPaymentMethodsAsync(CancellationToken ct = default);
}

public class ProductService : IProductService
{
    private const int MaxSearchResults = 10; // spec: search returns max 10 rows

    private readonly BeeMartDbContext _db;
    public ProductService(BeeMartDbContext db) => _db = db;

    public async Task<IReadOnlyList<ProductDto>> SearchAsync(string? keyword, CancellationToken ct = default)
    {
        var q = _db.MsProducts.AsNoTracking().Where(p => p.Stsrc);

        if (!string.IsNullOrWhiteSpace(keyword))
        {
            var k = keyword.Trim();
            q = q.Where(p => EF.Functions.Like(p.Name, $"%{k}%"));
        }

        return await q.OrderBy(p => p.Name)
            .Take(MaxSearchResults)
            .Select(p => new ProductDto
            {
                IdProduct = p.IdProduct,
                Name = p.Name,
                Weight = p.Weight,
                Stock = p.Stock,
                Price = p.Price,
                Discount = p.Discount
            })
            .ToListAsync(ct);
    }

    public async Task<ProductDto?> GetAsync(string idProduct, CancellationToken ct = default)
    {
        return await _db.MsProducts.AsNoTracking()
            .Where(p => p.IdProduct == idProduct && p.Stsrc)
            .Select(p => new ProductDto
            {
                IdProduct = p.IdProduct,
                Name = p.Name,
                Weight = p.Weight,
                Stock = p.Stock,
                Price = p.Price,
                Discount = p.Discount
            })
            .FirstOrDefaultAsync(ct);
    }

    public async Task<IReadOnlyList<PaymentMethodDto>> GetPaymentMethodsAsync(CancellationToken ct = default)
    {
        return await _db.LtPaymentMethods.AsNoTracking()
            .Where(m => m.Stsrc)
            .OrderBy(m => m.IdPaymentMethod)
            .Select(m => new PaymentMethodDto
            {
                IdPaymentMethod = m.IdPaymentMethod,
                MethodName = m.MethodName
            })
            .ToListAsync(ct);
    }
}
