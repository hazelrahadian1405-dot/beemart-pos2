using System.Data;
using BeeMart.Api.Data;
using BeeMart.Api.Models.Dtos;
using BeeMart.Api.Models.Entities;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace BeeMart.Api.Services;

public interface ITransactionService
{
    Task<TransactionDto> CreateAsync(string idUser, string username, CreateTransactionRequest req, CancellationToken ct = default);

    /// <summary>Invoice number the next transaction will most likely receive (shown read-only on the page).</summary>
    Task<string> PeekNextInvoiceAsync(string idUser, CancellationToken ct = default);

    /// <summary>
    /// Paged transaction history for a single date. Admin sees all cashiers;
    /// a Cashier sees only their own. Ordered by TransactionDate ascending.
    /// </summary>
    Task<PagedResult<TransactionDto>> GetHistoryAsync(
        string requesterId, string requesterRole, DateOnly date, int page, int pageSize, CancellationToken ct = default);
}

public class TransactionService : ITransactionService
{
    private const int MaxPageSize = 20; // spec: max 20 rows per page

    private readonly BeeMartDbContext _db;
    private readonly IInvoiceNumberGenerator _invoice;
    private readonly IDateTimeProvider _clock;

    public TransactionService(BeeMartDbContext db, IInvoiceNumberGenerator invoice, IDateTimeProvider clock)
    {
        _db = db;
        _invoice = invoice;
        _clock = clock;
    }

    public Task<string> PeekNextInvoiceAsync(string idUser, CancellationToken ct = default) =>
        _invoice.NextAsync(idUser, _clock.NowWib, ct);

    public async Task<TransactionDto> CreateAsync(string idUser, string username, CreateTransactionRequest req, CancellationToken ct = default)
    {
        // Non-relational providers (InMemory in tests) have no transactions or locks.
        if (!_db.Database.IsRelational())
            return await CreateOnceAsync(idUser, username, req, ct);

        // Checkouts run one at a time. The invoice running number is shared by all cashiers
        // and stock is read-then-decremented, so two concurrent checkouts would otherwise get
        // the same invoice number or overwrite each other's stock update. An exclusive
        // application lock held for the length of the transaction serializes them.
        await using var tx = await _db.Database.BeginTransactionAsync(ct);

        var rc = new SqlParameter("@rc", SqlDbType.Int) { Direction = ParameterDirection.Output };
        await _db.Database.ExecuteSqlRawAsync(
            "EXEC @rc = sp_getapplock @Resource = N'BeeMart.Checkout', @LockMode = N'Exclusive', " +
            "@LockOwner = N'Transaction', @LockTimeout = 15000", new object[] { rc }, ct);
        if (rc.Value is int code && code < 0)
            throw new ServiceException("Sistem sedang sibuk, silakan coba lagi.");

        var result = await CreateOnceAsync(idUser, username, req, ct);
        await tx.CommitAsync(ct);   // releases the lock
        return result;
    }

    private async Task<TransactionDto> CreateOnceAsync(string idUser, string username, CreateTransactionRequest req, CancellationToken ct)
    {
        if (req.Items is null || req.Items.Count == 0)
            throw new ServiceException("Keranjang belanja masih kosong");

        var method = await _db.LtPaymentMethods
            .FirstOrDefaultAsync(m => m.IdPaymentMethod == req.IdPaymentMethod && m.Stsrc, ct)
            ?? throw new ServiceException("Metode pembayaran tidak valid");

        // Consolidate duplicate product lines.
        var merged = req.Items
            .GroupBy(i => i.IdProduct)
            .Select(g => new { IdProduct = g.Key, Qty = g.Sum(x => x.Qty) })
            .ToList();

        var productIds = merged.Select(m => m.IdProduct).ToList();
        var products = await _db.MsProducts
            .Where(p => productIds.Contains(p.IdProduct) && p.Stsrc)
            .ToDictionaryAsync(p => p.IdProduct, ct);

        var now = _clock.NowWib;
        var header = new TrTransaction
        {
            IdTransaction = Guid.NewGuid().ToString(),
            InvoiceNo = await _invoice.NextAsync(idUser, now, ct),
            TransactionDate = now,
            IdUser = idUser,
            IdPaymentMethod = method.IdPaymentMethod,
            Stsrc = true,
            Datein = now,
            Userin = username
        };

        decimal total = 0m;
        var detailDtos = new List<TransactionDetailDto>();

        foreach (var line in merged)
        {
            if (!products.TryGetValue(line.IdProduct, out var product))
                throw new ServiceException("Barang tidak ditemukan");

            if (line.Qty < 1)
                throw new ServiceException("Qty minimal 1");

            if (line.Qty > product.Stock)
                throw new ServiceException("Jumlah barang yang dimasukkan melebihi sisa stok.");

            // Price captured at sale time; discount is a percentage.
            decimal unit = product.Price;
            decimal discPct = product.Discount;
            decimal gross = unit * line.Qty;
            decimal subTotal = Math.Round(gross - (gross * discPct / 100m), 2, MidpointRounding.AwayFromZero);
            total += subTotal;

            header.Details.Add(new TrTransactionDetail
            {
                IdTransactionDetail = Guid.NewGuid().ToString(),
                IdTransaction = header.IdTransaction,
                IdProduct = product.IdProduct,
                Qty = line.Qty,
                Price = unit,
                Discount = discPct,
                SubTotal = subTotal,
                Stsrc = true,
                Datein = now,
                Userin = username
            });

            product.Stock -= line.Qty;
            product.Dateup = now;
            product.Userup = username;

            detailDtos.Add(new TransactionDetailDto
            {
                IdProduct = product.IdProduct,
                ProductName = product.Name,
                Qty = line.Qty,
                Price = unit,
                Discount = discPct,
                SubTotal = subTotal
            });
        }

        header.TotalPrice = total;
        _db.TrTransactions.Add(header);
        await _db.SaveChangesAsync(ct);

        return new TransactionDto
        {
            IdTransaction = header.IdTransaction,
            InvoiceNo = header.InvoiceNo,
            TransactionDate = header.TransactionDate,
            IdUser = header.IdUser,
            CashierName = username,
            Username = username,
            IdPaymentMethod = method.IdPaymentMethod,
            PaymentMethod = method.MethodName,
            ItemCount = detailDtos.Sum(d => d.Qty),
            TotalPrice = header.TotalPrice,
            Details = detailDtos
        };
    }

    public async Task<PagedResult<TransactionDto>> GetHistoryAsync(
        string requesterId, string requesterRole, DateOnly date, int page, int pageSize, CancellationToken ct = default)
    {
        if (page < 1) page = 1;
        if (pageSize < 1 || pageSize > MaxPageSize) pageSize = MaxPageSize;

        var dayStart = date.ToDateTime(TimeOnly.MinValue);
        var dayEnd = dayStart.AddDays(1);

        var q = _db.TrTransactions.AsNoTracking()
            .Where(t => t.Stsrc && t.TransactionDate >= dayStart && t.TransactionDate < dayEnd);

        // Role-based scoping is enforced here on the server: Cashier -> own rows only; Admin -> all.
        bool isAdmin = string.Equals(requesterRole, "Admin", StringComparison.Ordinal);
        if (!isAdmin)
            q = q.Where(t => t.IdUser == requesterId);

        int total = await q.CountAsync(ct);

        var items = await q
            .OrderBy(t => t.TransactionDate)          // spec: ascending by date & time
            .ThenBy(t => t.InvoiceNo)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .Select(t => new TransactionDto
            {
                IdTransaction = t.IdTransaction,
                InvoiceNo = t.InvoiceNo,
                TransactionDate = t.TransactionDate,
                IdUser = t.IdUser,
                CashierName = t.User!.FullName,
                Username = t.User.Username,
                IdPaymentMethod = t.IdPaymentMethod,
                PaymentMethod = t.PaymentMethod!.MethodName,
                ItemCount = t.Details.Where(d => d.Stsrc).Sum(d => d.Qty),
                TotalPrice = t.TotalPrice,
                Details = t.Details.Where(d => d.Stsrc).Select(d => new TransactionDetailDto
                {
                    IdProduct = d.IdProduct,
                    ProductName = d.Product!.Name,
                    Qty = d.Qty,
                    Price = d.Price,
                    Discount = d.Discount,
                    SubTotal = d.SubTotal
                }).ToList()
            })
            .ToListAsync(ct);

        return new PagedResult<TransactionDto>
        {
            Items = items,
            Page = page,
            PageSize = pageSize,
            TotalItems = total
        };
    }
}
