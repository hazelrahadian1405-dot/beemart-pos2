# BeeMart — Project Plan & Requirements Traceability

This document maps the test brief (`BeeMart_ITBootcamp_Basic_2027.pdf`) to the
implementation and tracks what is done.

## 1. Architecture

- [x] Separation of Concerns: two projects — `BeeMart.WebClient` (UI) and `BeeMart.Api` (logic + data).
- [x] WebClient consumes data only via HTTP; **no** direct DB access.
- [x] Backend holds all business logic, validation, and persistence.

## 2. Tech rules

| Requirement                                        | Status | Where                                        |
|----------------------------------------------------|:------:|----------------------------------------------|
| ASP.NET Core, .NET 8                               |   ✅   | both `.csproj` target `net8.0`               |
| Frontend: Razor Pages / HTML-JS (no Bootstrap)     |   ✅   | `BeeMart.WebClient/Pages`, hand-written CSS  |
| Backend: ASP.NET Core API (controllers)            |   ✅   | `BeeMart.Api/Controllers`                    |
| EF Core → SQL Server                               |   ✅   | `BeeMartDbContext`, `UseSqlServer`           |
| JSON communication                                 |   ✅   | all endpoints return JSON envelopes          |
| Endpoint versioning                                |   ✅   | `Asp.Versioning`, routes `/api/v{version}`   |
| Pagination (max 20/page) on history                |   ✅   | `TransactionService.GetHistoryAsync`         |
| Informative error handling (toast/alert)           |   ✅   | `app.js` toast + `ApiResponse` messages      |
| Rupiah (IDR) format + local timezone (WIB)         |   ✅   | `Intl` id-ID + `DateTimeProvider` (Asia/Jakarta) |

## 3. Data model (from ERD)

| Table                 | PK                       | Key columns                                                        |
|-----------------------|--------------------------|--------------------------------------------------------------------|
| `MsUser`              | `IdUser` NVARCHAR(5)     | Username, FullName, PasswordHash, Role + audit                     |
| `LtPaymentMethod`     | `IdPaymentMethod` INT    | MethodName + audit                                                 |
| `MsProduct`           | `IdProduct` NVARCHAR(36) | Name, Weight, Stock, Price, Discount + audit                       |
| `TrTransaction`       | `IdTransaction` NVARCHAR(36) | InvoiceNo, TransactionDate, IdUser(FK), IdPaymentMethod(FK), TotalPrice + audit |
| `TrTransactionDetail` | `IdTransactionDetail` NVARCHAR(36) | IdTransaction(FK), IdProduct(FK), Qty, Price, Discount, SubTotal + audit |

Audit columns on every table: `Stsrc` (bit), `Datein`, `Userin`, `Dateup`, `Userup`.

Relationships: MsUser 1—* TrTransaction; LtPaymentMethod 1—* TrTransaction;
TrTransaction 1—* TrTransactionDetail; MsProduct 1—* TrTransactionDetail.

## 4. Feature checklist

### Login
- [x] Username & Password required (client + server validation)
- [x] Validate Username + Password + Role against `MsUser`
- [x] Password hashing (PBKDF2-SHA256); no plain text stored
- [x] Wrong username/password/role → `Invalid login`
- [x] Role dropdown: `Admin`→`Admin`, `Kasir`→`Cashier`

### Register
- [x] Username, Full Name, Password, Re-Password required
- [x] Password hashed before storage
- [x] Unique username → `username has already exists`

### New Transaction (Admin & Cashier)
- [x] Real-time clock (WIB)
- [x] Product search — max 10 results matching the keyword
- [x] "Pilih" button on each search row
- [x] "Barang Terpilih" panel shows item, unit price, remaining stock (minus what is already in the cart)
- [x] "Masukkan ke Keranjang" with stock check → `Jumlah barang yang dimasukkan melebihi sisa stok.`
- [x] Remove items from cart
- [x] Payment method dropdown fetched dynamically via API
- [x] On submit success → reset page + new invoice number for the next transaction
- [x] Invoice number `[5 userId][ddmmyy][3 running]`, server-generated, read-only

### Transaction History — Cashier
- [x] Date must be selected before searching
- [x] Date picker component
- [x] Pagination max 20/page, order by date ascending
- [x] Cashier sees only their own transactions
- [x] Header: `Role: <role> | Login: <username>`

### Transaction History — Admin
- [x] Date picker required
- [x] Admin sees all cashiers' transactions
- [x] Pagination max 20/page, ascending
- [x] Header: `Role: <role> | Login: <username>`

## 5. Acceptance criteria

- [x] All pages (Login, Register, New Transaction, History) present and functional
- [x] WebClient 100% depends on the API (no direct DB connection)
- [x] Auth + authorization enforced; history accurately separates Admin vs Cashier
- [x] Invoice numbers auto-generate with the correct format and run sequentially

## 6. Deliverables

- [x] Frontend folder (`BeeMart.WebClient`)
- [x] Backend folder (`BeeMart.Api`)
- [x] SQL script with DDL + seed DML (`database.sql`)
- [x] `.sln` + `.csproj` files
- [x] `appsettings.json` in both projects

## 7. Verification performed

Run against a real **SQL Server 2022 (16.0.4305.5, Developer edition)** with the
unmodified API and WebClient builds, starting from a server with no `BeeMart`
database:

- **First start:** the API created the `BeeMart` database and ran `database.sql`
  (5 tables, 10 indexes, 4 foreign keys, 3 payment methods, 370 products, 2 users).
  A restart left the existing data alone.
- **Browser, 47/47 checks** in headless Chromium, covering every page and rule above.
  Examples: a cart of Samyang Hot Chicken ×2 (10%), Indomie Mi Goreng Spesial ×5
  and Lemonilo Mie Goreng ×3 (5%) totals exactly **Rp 76.475**; search returns at
  most 10 rows and ignores case; a second cashier can't see the first one's
  transactions; Admin sees everyone's, 20 per page in ascending order.
- **Database, 23/23 checks** read straight from SQL Server: registered passwords are
  hashed, stock is decremented, every row has `Userin`, the detail rows keep the
  price and discount at the time of sale, and every invoice is
  `[IdUser][ddMMyy][3 digits]`.
- **Concurrency:** 40 simultaneous checkouts by two cashiers all succeeded, with
  unique, gap-free invoice numbers and stock down by exactly 40. 25 simultaneous
  checkouts of a product with 20 in stock: exactly 20 succeeded, the other 5 got the
  stock message, and stock ended at 0.

`database.sql` was also run directly (outside the API) on an empty database, with
the same table and row counts.

## 8. Notes / assumptions

- Section 3's validation points (a–c) in the PDF duplicate the Register rules
  (an apparent copy/paste error); implemented the transaction behavior described
  in points d–i, which is the substantive spec for that screen.
- `IdUser` is generated as a zero-padded 5-digit sequence (`00001`, `00002`, …)
  so it fits NVARCHAR(5) and forms a clean invoice prefix.
- `Discount` is treated as a percentage (DECIMAL(5,2)); subtotal = price × qty − discount%.
- `database.sql` is the provided script, used as-is, plus one added INSERT for the
  admin and kasir test accounts (the brief requires seeding users, and passwords
  must be stored hashed).
- `Weight` holds grams in the provided data (e.g. 85, 600, 2000). The UI shows
  values under 1000 as grams ("85 g") and the rest as kilograms ("1,5 Kg").
- A comment in the provided script says the invoice number is generated by the
  front end. Here the API generates it and the page only displays it, because the
  brief puts all business logic in the API and the number must be unique and not
  editable by the user. The format is the same.
- The invoice running number is shared by all cashiers and resets daily, which is
  what the Admin history mockup shows. The number shown on the page before saving
  is a preview; the server assigns the final number on save. Checkouts are
  serialized with a SQL Server application lock (`sp_getapplock`), so two cashiers
  saving at the same moment can't get the same number or oversell stock.
- The spec text mentions a dialog for quantity entry; the mockup shows an inline
  "Barang Terpilih" panel. The UI follows the mockup.
- The admin and cashier history views share one page; the API decides which rows
  each role may see.
